package e.alexsalasanleandro.gestiomaterialgires;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ImportantUserActivity extends AppCompatActivity {

    private static final int EDIT_NAME = 3;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> list_return;
    private ArrayAdapter<String> adapterpre;
    private ArrayList<String> list_prep;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_important_user);
        list_return = new ArrayList<String>();
        list_return.add("Forat Mico");
        list_return.add("Escalada Gelida");
        list_return.add("Guara");
        list_return.add("Picos de Europa");

        list_prep = new ArrayList<String>();
        list_prep.add("Escalada Vallirana");
        list_prep.add("Matinal GIRES");
        list_prep.add("Material Autorescat");
        ListView List_prep = findViewById(R.id.list_preperar);
        ListView list_ret = findViewById(R.id.list_retornar);
        adapterpre = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,list_prep);
        adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,list_return);
        list_ret.setAdapter(adapter);
        List_prep.setAdapter(adapterpre);
        list_ret.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText( ImportantUserActivity.this,String.format( list_return.get(i) ),Toast.LENGTH_SHORT ).show();
            }
        } );
        List_prep.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText( ImportantUserActivity.this,String.format( list_prep.get(i) ),Toast.LENGTH_SHORT ).show();
            }
        } );


    }

    public void newcommand(View view) {
        final AlertDialog.Builder novacomanda = new AlertDialog.Builder(this);
        novacomanda.setMessage("Introduir nom de la comanda"); //posar - ho com a recurs que es pugui traduir
        novacomanda.setTitle("Comanda");
        final EditText namecomanda = new EditText(this);
        novacomanda.setView(namecomanda);


        novacomanda.setPositiveButton("Crear", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name =namecomanda.getText().toString();
                if (name.isEmpty()){
                    Toast.makeText(ImportantUserActivity.this,"Posa un nom", Toast.LENGTH_SHORT).show();
                }else {
                list_prep.add(name);
                novacomanda(name);}
            }
        });
        novacomanda.setNegativeButton("Cancel·lar",null);
        novacomanda.create();
        novacomanda.show();
    }

    public void novacomanda (String nomcomanda){
        Intent intent = new Intent(this,EditCommand.class); //El·liminar espais si en posa
        intent.putExtra("name",nomcomanda);
        startActivityForResult(intent,EDIT_NAME);


    }
}
