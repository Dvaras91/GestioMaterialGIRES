package e.alexsalasanleandro.gestiomaterialgires;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class EditCommand extends AppCompatActivity {

    private static final int EDIT_NAME = 1;
    private ComandListAdapter adapter;
    private ArrayList<Itemcomandprop> listmaterial;

    String nomcom = "Nom per defecte";
    TextView Titulcomanda;
    String noumaterial;
    ListView list_material;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_command);

        Toast.makeText( EditCommand.this, "Clica al botó + per afegir material",Toast.LENGTH_SHORT).show();  //FALTARIA FER RECURS
        Intent intent = getIntent();
        if (intent != null){
            nomcom = intent.getStringExtra("name");

        }
        Titulcomanda = findViewById(R.id.lbl_namecommand);
        Titulcomanda.setText("Nom de la comanda: "+nomcom);
        list_material = findViewById( R.id.list_material );
        listmaterial = new ArrayList<>(  );
        adapter = new ComandListAdapter( this,R.layout.itemedit,listmaterial );
        list_material.setAdapter( adapter );

        list_material.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long l) {
                listmaterial.get( pos ).toggleChecked();
                adapter.notifyDataSetChanged();
            }
        } );



    }

    public void addItem(View view) {
        Intent intent = new Intent( this,ListMaterial.class );
        startActivityForResult( intent,EDIT_NAME );
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode){
            case EDIT_NAME:
                if (resultCode==RESULT_OK){
                    noumaterial = data.getStringExtra( "material" );
                    listmaterial.add(new Itemcomandprop( noumaterial ));
                    adapter.notifyDataSetChanged();
                    list_material.smoothScrollToPosition( listmaterial.size()-1 );
                }
        default:
        super.onActivityResult( requestCode, resultCode, data );
    }}
}
