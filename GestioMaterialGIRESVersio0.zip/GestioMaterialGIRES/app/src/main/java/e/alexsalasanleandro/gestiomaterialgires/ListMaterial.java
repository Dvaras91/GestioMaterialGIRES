package e.alexsalasanleandro.gestiomaterialgires;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class ListMaterial extends AppCompatActivity {

    private ArrayAdapter<String> adapter;
    private ArrayList<String> list_item;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_list_material );
        Intent intent = getIntent();
        list_item = new ArrayList<>(  );
        list_item.add( "Arnes" );
        list_item.add( "Casc" );
        list_item.add( "Raquetes" );
        list_item.add( "Corda 1/2" );
        list_item.add( "Neopreno" );
        list_item.add( "Bagues" );
        list_item.add( "Cordino" );
        list_item.add( "Corda 40m estàtica" );
        list_item.add( "Dissipador" );
        final ListView list_material = findViewById( R.id.list_material );
        adapter = new ArrayAdapter<String>( this,android.R.layout.simple_list_item_1,list_item );
        list_material.setAdapter( adapter );
        list_material.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText( ListMaterial.this,String.format( list_item.get(i) ),Toast.LENGTH_SHORT ).show();
                Intent data = new Intent(  );
                data.putExtra( "material",list_item.get( i ) );
                setResult( RESULT_OK,data );
                finish();
            }
        } );

    }
}
